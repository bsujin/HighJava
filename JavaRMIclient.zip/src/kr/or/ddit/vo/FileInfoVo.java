package kr.or.ddit.vo;

import java.io.Serializable;

public class FileInfoVo implements Serializable{

	// 파일 전송용 VO클래스 
		
		private String fileName;	//파일 명이 저장될 변수 
		private byte[] fileData;	//파일 내용이 저장될 변수 
		
		public String getFileName() {
			return fileName;
		}
		public void setFileName(String fileName) {
			this.fileName = fileName;
		}
		public byte[] getFileData() {
			return fileData;
		}
		public void setFileData(byte[] fileData) {
			this.fileData = fileData;
		}
		
		
	

}
