package test;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Main {

	public static void main(String[] args) {
		
		
		String host = "smtp.naver.com";
		
		// 보내는 계정
		final String user = "db4906@naver.com";
		// 비밀번호
		final String password = "rhrnak12";

		// 받는사람
		// 여러명한테 보낼 시 배열 사용
		String[] to = { "db4906@gmail.com", "dndb4906@daum.net",
				"bsjin7231@naver.com", "bsjin7231@gmail.com" };

		// 세션 객체 가져오기 / Get the session object
		// Properties 객체를 통해 정보를 관리
		Properties props = new Properties();	// 메일 서버에 연결하기 위한 속성 설정 작업 작성
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.auth", "true");

		// Session : 메일 서버와의 세션 관리
		// SMTP 서버 정보와 사용자 정보를 기반으로 Session 클래스의 인스턴스를 생성
		Session session = Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {	// 패스워드 인증이 필요한 경우
						return new PasswordAuthentication(user, password);
					}
				});

		// Message 클래스의 객체를 사용하여 수신자와 내용, 제목의 메시지를 작성한다.

		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(user));
			
			// 여러명한테 보낼 때 for문으로 다중 전송이 가능
			for (int i = 0; i < to.length; i++) {
				message.addRecipient(Message.RecipientType.TO,
						new InternetAddress(to[i]));
			}

			// 제목
			message.setSubject("제목");

			// 내용
			message.setText("내용");

			// Transport : 메일 전송
			// 작성한 메시지를 전달한다.
			Transport.send(message);
			System.out.println("전송이 완료되었습니다.");

		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

}
