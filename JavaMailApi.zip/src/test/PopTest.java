package test;

import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.AddressException;

public class PopTest {
    public static void open() throws AddressException, MessagingException {
        String host = "pop.naver.com";
        
        final String username = "bsjin7231"; // @naver.com 은 제외하고 아이디만.
        final String password = "ksj0515!!";
        int port=995;
   
        
        Properties props = System.getProperties();
        
        props.put("mail.pop3.host", host);
        props.put("mail.pop3.port", port);
        props.put("mail.pop3.auth", "true");
        props.put("mail.pop3.ssl.enable", "true");
        props.put("mail.pop3.ssl.trust", host);
        
        Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
            String un=username;
            String pw=password;
            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                return new javax.mail.PasswordAuthentication(un, pw);
            }
        });
        session.setDebug(false);
        
        Store store = session.getStore("pop3");
        store.connect();
        
        Folder folder = store.getFolder("INBOX");
        folder.open(Folder.READ_ONLY);
        
        Message[] messages = folder.getMessages();
        
        for(Message message : messages) {
            System.out.print(":::::::::::::::::::::::::::::::::::");
            System.out.println(message.getSubject());
        }
        
        store.close();
    }
}