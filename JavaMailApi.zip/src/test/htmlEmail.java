package test;

import java.io.File;

import org.apache.commons.mail.HtmlEmail;

public class htmlEmail {

public static void main(String[] args) {
	
		//html 객체생성
		HtmlEmail email = new HtmlEmail();
		
		//smtp 서버연결설정
		email.setHostName("smtp.naver.com");
//		email.setSmtpPort(465);
		email.setAuthentication("bsjin7231@naver.com", "****");
		
		//이미지 파일 정보 준비
		File imgFile  = new File("D:\\D_Other\\영화4.jpg");
		
		//메일보내기
		//html 한글이 깨지지 않게 하기 위해 문자셋을 설정해줘야한다.
		String result = "fail";
		
		//받는사람이 여러명일 경우 배열로 생성해준다.
		String[] to = { "db4906@gmail.com", "dndb4906@daum.net",
				"bsjin7231@naver.com", "bsjin7231@gmail.com" };

	
		try {
			//보내는 사람 설정
			email.setFrom("bsjin7231@naver.com","관리자");
			
			//받는 사람 설정
//			email.addTo("bsjin7231@gmail.com","백수진");		받는사람이 1명일때 
			email.addTo(to);							// 받는 사람이 여러명일때 
			
			//메일 제목 설정 
			email.setSubject("메일 테스트");
			
			//본문설정
			StringBuilder sb = new StringBuilder(); //StringBuilder라는 가변객체 사용
			sb.append("<html><body>");			    //append로 문자열을 더하고 다시 toString 함수로 반환
			sb.append("테스트 메일 본문입니다.");
			sb.append("<img src=cid:");		//이메일에 첨부한 이미지는 웹서버에 위치한 것이 아니기 때문에 URL로 이미지의 위치를 지정할 수 없어
											//이메일 헤더인 Content-ID에 이미지 이름을 지정하고 <IMG> 태그 속성에 헤당 Content-ID의 이름을 지정하면 이미지가 표시 
			sb.append(email.embed(imgFile));
			sb.append("></body></html>");
			
			//문자셋 설정
			email.setCharset("UTF-8");		//한글이 깨지지 않게 메일의 캐릭터셋을 설정
			email.setHtmlMsg(sb.toString());	//StringBuilder를 toString 함수로 반환
			
			//메일 전송
			result = email.send();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("결과 : " + result);
		}
		
	}


}
