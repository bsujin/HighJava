package test;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;

public class MultiEmail {

	public static void main(String[] args) {
		
		// EmailAttachment클래스는 첨부파일을 지정할 때 사용
		EmailAttachment attachment = new EmailAttachment();
		
		attachment.setPath("C:\\Users\\Sub-02\\Desktop\\background.jpg");	//전송할 파일
		attachment.setDisposition(EmailAttachment.ATTACHMENT);
		attachment.setDescription("commons-email api");
		attachment.setName("background.jpg");		// 파일의 이름을 지정
		
		// MultiPartEmail : 파일을 이메일에 첨부해주는 기능을 제공해 준다
		MultiPartEmail email = new MultiPartEmail();
		
		// 서버 연결 설정
		email.setHostName("smtp.naver.com");
		email.setAuthentication("db4906", "*****");		//아이디, 비밀번호
		email.setCharset("UTF-8");
		
		//받는 사람이 여러명일때 배열로 이용
		String[] to = { "dhwpgus7535@naver.com", "dndb4906@daum.net",
						"bsjin7231@naver.com", "bsjin7231@gmail.com" };
		
		try {
			email.setFrom("db4906@naver.com", "동기");		//보내는 사람
//			email.addTo("dndb4906@daum.net", "유동기");		//받는 사람
			email.addTo(to);								//받는 사람이 여러명일 경우
			email.setSubject("첨부파일 테스트 메일입니다~");		//제목
			email.setMsg("내용입니다~!");						//내용
			
			email.attach(attachment);	// attach()를 사용해서 첨부할 파일을 추가
			email.send();				// 전송
			
			System.out.println("전송 완료!!");
			
		} catch (EmailException e) {
			e.printStackTrace();
		}	
	}

}

