package genericTest;

public class B_ConstTest {

	//색깔과 관련된 상수 만들기 
	public final static int RED = 1;
	public final static int GREEN = 2;
	public final static int BLUE = 3;
	
	
	public final static int ONE = 1;
	public final static int TWO = 2;
	public final static int THREE = 3;

	
	

}
