package kr.or.ddit.basic;

import java.util.ArrayList;
import java.util.Collections;

/*
 	문제) 10마리의 말들이 경주하는 경마 프로그램 작성하기
 	
 		경주마는 Horse라는 이름의 클래스로 구성하고
 		이 클래스는 말이름(String), 등수(int), 현재위치(int)를 맴버변수로 같는다.
 		그리고, 이 클래스에는 등수를 오름차순으로 처리하는 내부 정렬기준이 있다.
 				(comparable인터페이스 구현하기)
 		- 이 Horse클래스는 쓰레드로 작성한다.
 		
 		- 경기 구간은 1 ~ 50구간으로 되어 있다.
 		
 		- 경기 중 중간 중간에 각 말들의 위치를 나타내시오.
 		
 		예)
 		01번말 : ----->----------------------------------
 		02번말 : --->-------------------------------------
 		...
 		10번말 : ------->--------------------------------
 
 		- 경기가 끝나면 등수 순으로 경기 결과를 출력한다.
 		
 		말도 쓰레드 
 
 */

public class ThreadTest13 {

	public static void main(String[] args) {
		Horse[] players = new Horse[] {
				new Horse("01번말",0,0),
				new Horse("02번말",0,0),
				new Horse("03번말",0,0),
				new Horse("04번말",0,0),
				new Horse("05번말",0,0),
				new Horse("06번말",0,0),
				new Horse("07번말",0,0),
				new Horse("08번말",0,0),
				new Horse("09번말",0,0),
				new Horse("10번말",0,0)
		};
		
		for(int i=0; i<players.length; i++) {
			players[i].start();
		}
		
		RacingStart rs = new RacingStart(players);
		
		rs.start();
		
		try {
			rs.join();
		} catch (InterruptedException e) {
			// TODO: handle exception
		}
		ArrayList<Horse> list = new ArrayList<>();
		for(int i=0; i<players.length;i++) {
			list.add(rs.getHorse()[i]);
		}
		
		
		Collections.sort(list);
		System.out.println("====결과====");
		for(int i = 0; i<players.length; i++) {
			System.out.println(i+1+"등 : "+list.get(i).getHoresname());
		}
		System.out.println("===========");
		
		
	}

}

//말 클래스 구현
class Horse extends Thread implements Comparable<Horse>{
	private String horesname;
	private int rank;
	private int location;
	private static int count;
	


	public Horse(String horesname, int rank, int location) {
		super();
		this.horesname = horesname;
		this.rank = rank;
		this.location = location;
	}

	
	
	
	public String getHoresname() {
		return horesname;
	}




	public void setHoresname(String horesname) {
		this.horesname = horesname;
	}




	public int getRank() {
		return rank;
	}




	public void setRank(int rank) {
		this.rank = rank;
	}




	public int getLocation() {
		return location;
	}




	public void setLocation(int location) {
		this.location = location;
	}




	@Override
	public void run() {
		
		for(int i = 1; i<=50; i++) {
			location++;
			if(location==50) {
				count++;
				rank = count;
			}
			try {
				Thread.sleep((int)(Math.random()*500+101));
			} catch (InterruptedException e) {
				// TODO: handle exception
			}
		}
	}
	
	@Override
	public int compareTo(Horse horse) {
		return Integer.compare(this.rank, horse.getRank());
	}
	
	
}


class RacingStart extends Thread{
	private int count = 0;
	private Horse[] horse;
	
	public RacingStart(Horse[] horse) {
		this.horse = horse;
	}



	public Horse[] getHorse() {
		return horse;
	}



	public void setHorse(Horse[] horse) {
		this.horse = horse;
	}



	@Override
	public void run() {

		
		while(count!=10) {
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO: handle exception
			}
			
			System.out.println();
			
			for(int i = 0; i<=9; i++) {
				String section = "";
				System.out.print(horse[i].getHoresname()+" : ");
				for(int j = 1; j<=50; j++) {
					if(j==horse[i].getLocation()) {
						section += ">";
					}else {
						section += "-";
					}
						
				}
				System.out.println(section);
				
				
			}
			for(int j = 0; j<horse.length; j++) {
				if(horse[j].getLocation()==50) {
					count ++;
				 	}
				}
			
			if(count != 10) {
				count=0;
			}
			
			
			
		}
		
	
	}
}


