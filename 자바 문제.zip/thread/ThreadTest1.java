package kr.or.ddit.basic;

import java.util.Arrays;

/*

문제 ] 10마리의 말들이 경주하는 경마 프로그램
	
	- 경주마는 Horse라는 이름의 클래스로 구성하고 이 클래스는 말이름(String), 등수 (int), 현재위치(int)를
	멤버변수로 갖는다.
	- 이 클래스에는 등수를 오름차순으로 처리하는 내부 정렬 기준이 있다.
		(Comparable인터페이스 구현하기)
	- Horse 클래스는 스레드로 작성
	- 경기구간은 1 ~ 50 구간으로 되어 있다.
	- 경기  중간 중간에 각 말들의 위치를 나타내시오.
		ex)
		 01번말 : ---------->------------------------------
		 02번말 : ------->---------------------------------
		 ....
		 10번말 : ------------->---------------------------
		 
	- 경기가 끝나면 등수 순으로 경기 결과를 출력한다.

*/
public class ThreadTest13 {
	public static boolean abcd = true;
	public static void main(String[] args) {
		Horse[] horses = new Horse[] {
				new Horse("1번말"),
				new Horse("2번말"),
				new Horse("3번말"),	
				new Horse("4번말"),
				new Horse("5번말"),
				new Horse("6번말"),	
				new Horse("7번말"),
				new Horse("8번말"),
				new Horse("9번말"),	
		};
		for(Horse ho : horses) {
			ho.start();
		}
		Display dp = new Display(horses);
		dp.start();
		for(Horse ho : horses) {
			try {
				ho.join();
				ThreadTest13.abcd = false;
			} catch (InterruptedException e) {
				// TODO: handle exception
			}
		}
		System.out.println();
		System.out.println("등수 ");
		for(int i = 0; i < Horse.a.length; i++) {
			System.out.println(i+1 + " 등  : " + Horse.a[i]);
		}

	}

}

class Horse extends Thread {
	public static int rank = 0;
	public String name;
	public int st; 
	public static String a[] = new String [9];
	
	public Horse(String name) {
		this.name = name;
	}

	@Override
	public void run() {
		for(int i = 1; i <= 50; i++) {
			try {
				Thread.sleep((int)(Math.random() * 400 + 101));
				st = i;
			} catch (InterruptedException e) {
				// TODO: handle exception
			}
		}
//		System.out.println(name + "도착");
		Horse.a[Horse.rank] = name;
		Horse.rank++;
	}
}

class Display extends Thread{
	Horse[] horses;

	public Display(Horse[] horses) {
		super();
		this.horses = horses;
	}
	
	@Override
	public void run() {
		while(true) {
			if(ThreadTest13.abcd == false) {
				break;
			} else {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO: handle exception
			}
			for(Horse ho : horses ) {
				System.out.print(ho.name + " 위치는 ");
				for(int j = 1; j <= 50; j++) {
					System.out.print("-");
					if(j == ho.st) {
						System.out.print(">");
					}
				}
				System.out.println();
			}
			System.out.println();
			}
		}
	}
	
}




