package kr.or.ddit.basic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Hotel {
	HashMap<Integer,Room> room;
	ArrayList<Room> arrayroom;
	Scanner sc = new Scanner(System.in);
	
	public Hotel() {
		room = new HashMap<>();
		arrayroom = new ArrayList<>();
		room.put(201, new Room(201, "싱글룸", "-"));
		room.put(202, new Room(202, "싱글룸", "-"));
		room.put(203, new Room(203, "싱글룸", "-"));
		room.put(204, new Room(204, "싱글룸", "-"));
		room.put(205, new Room(205, "싱글룸", "-"));
		room.put(206, new Room(206, "싱글룸", "-"));
		room.put(207, new Room(207, "싱글룸", "-"));
		room.put(208, new Room(208, "싱글룸", "-"));
		room.put(209, new Room(209, "싱글룸", "-"));
		
		room.put(301, new Room(301, "더블룸", "-"));
		room.put(302, new Room(302, "더블룸", "-"));
		room.put(303, new Room(303, "더블룸", "-"));
		room.put(304, new Room(304, "더블룸", "-"));
		room.put(305, new Room(305, "더블룸", "-"));
		room.put(306, new Room(306, "더블룸", "-"));
		room.put(307, new Room(307, "더블룸", "-"));
		room.put(308, new Room(308, "더블룸", "-"));
		room.put(309, new Room(309, "더블룸", "-"));
		
		room.put(401, new Room(401, "스위트룸", "-"));
		room.put(402, new Room(402, "스위트룸", "-"));
		room.put(403, new Room(403, "스위트룸", "-"));
		room.put(404, new Room(404, "스위트룸", "-"));
		room.put(405, new Room(405, "스위트룸", "-"));
		room.put(406, new Room(406, "스위트룸", "-"));
		room.put(407, new Room(407, "스위트룸", "-"));
		room.put(408, new Room(408, "스위트룸", "-"));
		room.put(409, new Room(409, "스위트룸", "-"));
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Hotel().start();
	}

	private void start() {
		System.out.println("***********************************");
		System.out.println("\t호텔문을 열었습니다. 오서오십시오.");
		System.out.println("***********************************");
		while (true) {
		System.out.println("---------------------------------------");
		System.out.println("어떤 업무를 하시겠습니까?");
		System.out.println("1.체크인    2.체크아웃    3.객실상태    4업무종료");
		System.out.println("---------------------------------------");
		System.out.print("선택>> ");
		int input = Integer.parseInt(sc.nextLine());
		switch (input) {
		case 1:
			checkInRoom();
			break;
		case 2:
			checkOutRoom();
			break;
		case 3:
			displayRoom();
			break;
		case 4:
			System.out.println("***********************************");
			System.out.println("\t호텔문을 닫았습니다.");
			System.out.println("***********************************");
			System.exit(0);
		default:
			System.out.println("없는 메뉴 입니다.");
			break;
		}
		
		}
		
	}

	private void checkOutRoom() {
		System.out.println("-----------------------------");
		System.out.println(" 체크인 작업");
		System.out.println("-----------------------------");
		System.out.print("체크아웃 할 방 번호를 입력하세요 ");
		System.out.print("방 번호 입력 >> ");
		int roomNum = Integer.parseInt(sc.nextLine());
		if(roomNum<201||roomNum>209&&roomNum<301||roomNum>309&&roomNum<401||roomNum>409) {
			System.out.println(roomNum + "호 객실은 존재하지 않습니다.");
		}else if(room.get(roomNum).getRoomUser().equals("-")) {
			System.out.println(roomNum+"호 객실에는 체크인 한 사람이 없습니다.");
		}else {
			System.out.println(roomNum+"호 객실의 " + room.get(roomNum).getRoomUser()+
					"님 체크아웃을 완료하였습니다.");
			room.get(roomNum).setRoomUser("-");
		}
	}

	private void checkInRoom() {
		System.out.println("-----------------------------");
		System.out.println(" 체크인 작업");
		System.out.println("-----------------------------");
		System.out.println("* 201~209 : 싱글룸");
		System.out.println("* 301~309 : 더블룸");
		System.out.println("* 401~409 : 스위트룸");
		System.out.println("-----------------------------");
		System.out.print("방 번호 입력 >> ");
		int roomNum = Integer.parseInt(sc.nextLine());
		if(roomNum<201||roomNum>209&&roomNum<301||roomNum>309&&roomNum<401||roomNum>409) {
			System.out.println(roomNum + "호 객실은 존재하지 않습니다.");
		}else if(room.get(roomNum).getRoomUser().equals("-")) {
			System.out.println("누구를 체크인 하시겠습니까?");
			System.out.print("이름 입력 >> ");
			String name = sc.nextLine();
			room.get(roomNum).setRoomUser(name);
			System.out.println("체크인이 완료되었습니다.");
		}else {
			System.out.println(roomNum + "호 객실은 이미 손님이 있습니다.");
		}
	}

	private void displayRoom() {
		System.out.println("------------------------------");
		System.out.println("\t현재 객실 상태");
		System.out.println("------------------------------");
		System.out.println("방 번호\t방 종류\t투숙객 이름");
		System.out.println("------------------------------");
		for(int key : room.keySet()) {
			arrayroom.add(room.get(key));
		}
		Collections.sort(arrayroom);
		for(int i = 0; i<arrayroom.size(); i++) {
			System.out.println(arrayroom.get(i).getRoomNumber()+"\t"+
					arrayroom.get(i).getRoomName()+"\t"+
					arrayroom.get(i).getRoomUser());
			
		}
		System.out.println("------------------------------");
		arrayroom.clear();
	}

}


class Room implements Comparable<Room>{
	private int roomNumber;
	private String roomName;
	private String roomUser;
	public Room(int roomNumber, String roomName, String roomUser) {
		super();
		this.roomNumber = roomNumber;
		this.roomName = roomName;
		this.roomUser = roomUser;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public String getRoomUser() {
		return roomUser;
	}
	public void setRoomUser(String roomUser) {
		this.roomUser = roomUser;
	}
	
	@Override
	public int compareTo(Room no) {
		
		return Integer.compare(this.roomNumber, no.getRoomNumber());
	}
	@Override
	public String toString() {
		return "Room [roomNumber=" + roomNumber + ", roomName=" + roomName + ", roomUser=" + roomUser + "]";
	}
	
}