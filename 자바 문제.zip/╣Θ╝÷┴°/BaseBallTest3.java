package kr.or.ddit.basic.Problem;

import java.util.ArrayList;
import java.util.HashSet;
import kr.or.ddit.basic.ScanUtill;

public class BaseBallTest3 {
	/*
	 * 1~9까지 난수 만들기 : set사용 순서가 맞는지 파악하기 위해 list로 저장 list의 값을 비교 입력받은 값도 list에 저장
	 * 
	 * 
	 * - 기능별로 매서드들을 따로따로 만들기
	 * 
	 * 
	 * 문제 ) Set과 List를 이용하여 숫자야구 프로그램을 작성하시오 컴퓨터의 숫자는 난수를 이용하여 구한다. (스트라이크는 S, 볼은 B로
	 * 나타낸다) 예시) 컴퓨터의 난수 ==> 957 3s 면 게임 끝
	 * 
	 * 실행예시) 숫자입력 ==> 3,5,8 3 5 8 ==> 1s 0b 숫자입력 ==> 7 8 9 7 8 9 ==> 0s, 2b 숫자입력 ==>
	 * 9 7 5 ==> 1s, 2b 숫자입력 ==> 9,5,7 9 5 7 ==> 3s 축하합니다. 당신은 4번째 만에 맞췄습니다.
	 */

	HashSet<Integer> random = new HashSet<>();
	ArrayList<Integer> computer;
	ArrayList<Integer> user = new ArrayList<>();

	public static void main(String[] args) {
		BaseBallTest3 start = new BaseBallTest3();

		start.random();
		start.insertNum();
		start.game();

	}

private void random() {
		// computer의 난수 저장하기

		while (random.size() < 3) {
			random.add((int) (Math.random() * 9) + 1);
		}
		System.out.println(random);
		computer = new ArrayList<>(random);
	}

	private void insertNum() {
		// user의 숫자 입력받기
		// 중복 없애기
		HashSet<Integer> insert = new HashSet<>();
		while (insert.size() < 3) {
		System.out.println("숫자를 입력하세요 > ");
			
		
		insert.add(ScanUtill.nextInt());
		System.out.println("입력한 숫자는 :" + insert);
		}
		user = new ArrayList<>(insert);
	}

	private void game() {
	int count = 0; // 횟수를 세줄 변수 설정
	int ball = 0;
	int strike = 0;

	
	while (true) {
		count++;
		ball=0;
		strike=0;
	// user의 숫자와 computer의 숫자를 비교
			for (int i = 0; i < computer.size(); i++) {
				for (int j = 0; j < user.size(); j++) {
					if (computer.get(i) == user.get(j)) {
						if (i == j) { // i와 j의 값이 같으면
							strike++;
						} else { // 값은 같으나 순서가 다르면
							ball++;
						}
					}
				}
			}System.out.println(ball + "B" + strike + "S");
			if (strike == 3) {
				System.out.println(count + " 번 만에 맞췄습니다.");
				break;
			} else {
				System.out.println("틀렸습니다. 다시 입력해주세요");
				user.clear();
			}
		}

	}
}
