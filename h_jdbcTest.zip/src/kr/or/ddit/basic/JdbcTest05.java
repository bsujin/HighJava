package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/*
 * 	LPROD테이블에 새로운 데이터 추가하기
 * 	
 * 추가할 데이터 중 Lprod_gu와 Lprod_nm을 직접 입력받아서 처리하고,
 * Lprod_id값은 현재의 Lprod_id값 중 제일 큰 값보다 1 증가된 값으로 한다.			-> 제일 큰값은 max사용 
 * 그리고, 입력받은 Lprod_gu가 이미 등록되어 있으면 다시 입력받아서 처리한다.
 * 
 * 어떤 조건에 맞는 데이터의 갯수를 구한다 ->갯수가 있으면 1 없으면 0   => 갯수는 count 사용 
 * 
 */

public class JdbcTest05 {

	public static void main(String[] args) {

		// 추가할 데이터를 입력받기

		Scanner scan = new Scanner(System.in);

		Connection conn = null;	//연결해주는 인터페이스 
		PreparedStatement pst = null;	// ?에 값을 넣어주도록 SQL문을 연결해줌 
		ResultSet rs = null;	//결과값을 담는 인터페이스 

		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "sem", "java");
			
			String gu = null;
			
			while (true) {
				System.out.println("추가할 Lprod_gu값을 입력 > ");
				gu = scan.nextLine();
				String sql = " SELECT count(*) FROM LPROD WHERE lprod_gu = ?";
				pst = conn.prepareStatement(sql);
				pst.setString(1, gu);
				rs = pst.executeQuery(); // 쿼리에 db에 보내고 결과를 rs에 담아줌
				if (rs.next()) { // 값을 가져오는것 = rs.next()는 true
					if (rs.getInt("count(*)") == 0) { // 값이 없으면 0 있으면 1
						break;
					}
					System.out.println("중복된 값이 있습니다. 다시 입력해주세요");
				}
			}
			
			System.out.println("추가할 Lprod_nm값을 입력 > ");
			String nm = scan.nextLine();

			String sql = "Insert into lprod values( (SELECT MAX(LPROD_ID)+1 FROM LPROD) , ? , ? ) ";
			pst = conn.prepareStatement(sql);
			pst.setString(1, gu);
			pst.setString(2, nm);
			
			int cnt = pst.executeUpdate();
			System.out.println("등록된 자료 : " + cnt);
			System.out.println("추가 완료 !!!");
					

		} catch (SQLException e) {
			e.printStackTrace();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if(rs!=null) try { rs.close();	} catch (Exception e) {	}
			if(pst!=null) try { pst.close();	} catch (Exception e) {	}
			if(conn!=null) try { conn.close();	} catch (Exception e) {	}
		}
		
	}
}

