package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


// 문제1 ) 사용자로부터 Lprod_id값을 입력받아 입력한 값보다  Lprod_id 값이 큰 자료들을 출력하시오

public class JdbcTest02 {

	public static void main(String[] args) {
		
		//DB작업에 필요한 변수 선언
		Connection conn = null;
//		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement ptsmt = null;
	
		Scanner scan = new Scanner(System.in);
		System.out.println("lprod_id 값을 입력하세요 >");
//		int input = Integer.parseInt(scan.nextLine());
		String input = scan.nextLine();   // statement 일때 입력시에    5 or 1=1;   ( ==> 전체 데이터가 나온다 )
											// preparedStatement 일때 입력시에는 하나의 데이터로 묶여서 데이터가 나오지 않는다. 
		
		
		
		// db연결하기
		try {

			// 1. 드라이버 로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 2. DB연결
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost", "sem", "java");

			// 3-1. 실행할 SQL문 작성

			// String sql = "select ?"+ " from lprod";
			String sql = "select  * from lprod where lprod_id > " + input ;
			System.out.println("실행한 sql문 : " + sql);
		
			// 3-2. Statement 객체 생성 ==> Connection 객체를 이용한다.
			
			//statement
//			stmt = conn.createStatement();
//			rs = stmt.executeQuery(sql);
			
			
			//preparedStatement
			ptsmt = conn.prepareStatement(sql);
			ptsmt.setString(1, input);
			
			rs = ptsmt.executeQuery();
			
			
			System.out.println("----------lprod보다 큰 값의 결과 출력하기----------");
			System.out.println("=============================================");			
			
			while(rs.next()) {
//				if(id<rs.getInt("LROD_ID"))  => 데이터가 많을 경우 좋지 않은 방법 
				 System.out.println("Lprod_id : " + rs.getInt("lprod_id"));	//잘못입력하면 false로 입력되어 출력되지 않는다
				 System.out.println("Lprod_gu : " + rs.getString("lprod_gu"));
				 System.out.println("Lprod_nm : " +  rs.getString("lprod_nm"));

				System.out.println("=============================================");			
			}

			System.out.println("전체 자료 출력 끝");
			
			} catch (SQLException e) {
				System.out.println("잘못입력했습니다.");
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				System.out.println("오류");
				e.printStackTrace();
			} finally {		//6. 사용했던 자원 반납하기
				if(rs!=null) { try{ rs.close(); } catch(SQLException e) { } }
//				if(stmt!=null) { try{ stmt.close(); } catch(SQLException e) { } } 
				if(ptsmt!=null) { try{ ptsmt.close(); } catch(SQLException e) { } }
				if(conn!=null) { try{ conn.close(); } catch(SQLException e) { } }
				
			}
	
		}
}
