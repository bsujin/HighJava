package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.print.DocFlavor.STRING;

public class JdbcTest04_preparestatement {
	// 은행 계좌번호 정보를 추가하는 예제 - insert문 사용  
		public static void main(String[] args) {

			// 데이터를 추가하기 
			Scanner scan = new Scanner(System.in);
			
			// insert문 사용시 변수 선언할 때 resultset이 필요하지 않다. 
			Connection conn = null;
			Statement stmt = null;
			PreparedStatement pstmt = null;
			
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "sem", "java");
				
				System.out.println("계좌 전화번호 정보 추가하기 ");
				System.out.print("계좌번호 : ");
				String bankNo = scan.next();
				
				System.out.print("은행명 : ");
				String bankNm = scan.next();
				
				System.out.print("예금주 명 : ");
				String userNm = scan.next();
				
				//PreparedStatement 객체를 이용하여 추가하기
				// ==> SQL문에서 데이터가 들어갈 자리를 물음표로 표시하여 작성한다.
				
				String sql = "Insert into bankinfo "
						+ "(bank_no, bank_name, bank_user_name, bank_date)" 
						+  " values ( ?, ?, ?, sysdate)";	//데이터가 들어갈 자리에 ?를 표시한다.
				
				// PreparedStatement 객체 생성하기
				// ==> 객체를 생성할 때 처리할 SQL문을 넣어 준다.
				
				pstmt = conn.prepareStatement(sql);
				
				// SQL문의 물음표(?) 자리에 들어갈 데이터를 셋팅한다.
				// 형식) pstmt.set자료형이름(물음표 순서, 셋팅할 데이터) ==> 물음표 순서에 맞게 들어갈 데이터(변수)를 넣어준다. 
				pstmt.setString(1, bankNo );
				pstmt.setString(2, bankNm );
				pstmt.setString(3, userNm );
				
				// 데이터 셋팅이 완료되면 SQL문을 실행하여 결과를 얻어온다.
				int cnt = pstmt.executeUpdate();
				
				System.out.println("반환값 cnt : " + cnt);	//insert가 실행된 횟수를 반환해준다.
				System.out.println("데이터 추가 완료!");
				
			} catch (SQLException e) {
				e.printStackTrace();
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} finally {
				if(stmt!=null) try { stmt.close();	} catch (Exception e) {	}
				if(pstmt!=null) try { pstmt.close();	} catch (Exception e) {	}
				if(conn!=null) try { conn.close();	} catch (Exception e) {	}
			}
			
			
		}

	}
