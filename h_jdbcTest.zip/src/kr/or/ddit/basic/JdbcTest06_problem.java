package kr.or.ddit.basic;

import java.awt.dnd.DnDConstants;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcTest06_problem {

	/*
	 * 
	 * 회원을 관리하는 프로그램 작성하기 (DB 시스템의 MYMEMBER테이블을 이용)
	 * 
	 * -- 처리조건 1. 아래 메뉴의 기능을 모두 구현한다. (CRUD 구현하기) 2. '자료추가' 에서는 회원 ID가 중복되는지 여부를
	 * 검사해서 중복되면 다시 입력 받도록 한다. 3. '자료 수정' 이나 '자료 삭제'는 회원 ID를 입력 받아 삭제한다. 4. '자료 수정'은
	 * 회원 ID를 제외한 전체 자료를 수정한다.
	 * 
	 * 메뉴 예시 )
	 * 
	 * ----- 작업 선택 ----- 
	 * 1. 자료 추가 (insert) 
	 * 2. 자료 삭제 (delete) 
	 * 3. 자료 수정 (update)
	 *  4. 전체 자료 출력 (select) 0. 작업 끝 -------------------- 작업 번호 >>
	 * 
	 * 
	 */

	Scanner scan = new Scanner(System.in);
	Connection conn = null; // 연결해주는 인터페이스
	PreparedStatement pst = null; // ?에 값을 넣어주도록 SQL문을 연결해줌
	ResultSet rs = null; // 결과값을 담는 인터페이스
	
	String name = null;
	String id = null;
	String addr = null;
	String tel = null;
	
	public static void main(String[] args) {
		new JdbcTest06_problem().view();

	}

	public void view() {

		while (true) {
		System.out.println("==============================");
		System.out.println("\t  회 원 관 리 프 로 그 램 \t");
		System.out.println("==============================");
		System.out.println("    1. 자 료 추 가 ");
		System.out.println("    2. 자 료 삭 제 ");
		System.out.println("    3. 자 료 수 정 ");
		System.out.println("    4. 자 료 검 색 ");
		System.out.println("    0. 작 업 종 료 ");
		System.out.println("==============================");

		System.out.print("입력>");
		int input = scan.nextInt();

		
			switch (input) {
			case 1: // 추가
				insert();
				break;
			case 2: // 삭제
				delete();
				break;

			case 3: // 수정
				update();
				break;

			case 4: // 검색
				search();
				break;

			case 0:
				System.out.println("프로그램을 종료합니다.");
				System.exit(0);

			default:
				System.out.println("번호를 잘못 입력하셨습니다.");
				System.out.println("다시 입력해주세요.");
				break;

			} // switch문 끝
			
		} // while문 끝

	}

	
	
	//검색하는 메서드 
	private void search() {
		
		System.out.println("==============================================");
		System.out.println(" \t 전 체 자 료 검 색 ");
		System.out.println(" ID       이름             전화번호                  주소");
		System.out.println("---------------------------------------------");
	

		try {
			
//			conn = DButil.getConnection();
//			conn = DButil2.getConnection();
			conn = DButil3.getConnection();
	
			String sql = "SELECT * FROM MYMEMBER";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			
			while(rs.next()) {
				 System.out.println(" " + rs.getString("mem_id") + " \t  " +  rs.getString("mem_name") + "\t  "
				 + rs.getString("mem_tel") + "\t" +  rs.getString("mem_addr"));
		
				 System.out.println("---------------------------------------------");
						
			}	
			System.out.println("==============================================");
			
		
		} catch (SQLException e) {
			e.printStackTrace();
			
		}finally {	
		if (rs != null)	try {rs.close();} catch (Exception e) {	e.printStackTrace();}
		if (pst != null)	try {	pst.close();} catch (Exception e) {		e.printStackTrace();}
		if (conn != null)	try {	conn.close();} catch (Exception e) { e.printStackTrace();}
	}
	}

	
	//수정하는 메서드
	private void update() {
		System.out.println("============================");
		System.out.println(" \t 자 료 수 정 ");
		System.out.println("============================");

		try {

			conn = DButil.getConnection();
			scan.nextLine();

		
//			while (true) {
//				System.out.print("수정할 자료의 Id를 입력해주세요 >");
//				id = scan.nextLine();
//				
//				String sql = "Select count(*) cnt From mymember WHERE mem_id = ?";
//				pst = conn.prepareStatement(sql);
//				pst.setString(1, id);
//				rs = pst.executeQuery();
//
//				if (rs.next()) {
//					if (rs.getInt("cnt") == 1) {
//						break;
//					}
//					System.out.println("등록된 아이디가 없습니다.");
//					return;
//				}
//			} // while문 끝
//			
			System.out.print("수정할 자료의 Id를 입력해주세요 >");
			id = scan.nextLine();
			
			//메서드 호출 - id를 파라미터 값으로 넘겨주기 
			int cnt = count(id);
			if(cnt==0) {	//0이면 id가 없는것 
				System.out.println("등록된 아이디가 없습니다.");
				return;
			}			
			System.out.print("수정할 자료의 이름을 입력해주세요 >");
			name = scan.nextLine();
			System.out.print("수정할 자료의 연락처를 입력해주세요 >");
			tel = scan.nextLine();
			
			System.out.print("수정할 자료의 주소를 입력해주세요>");
			addr = scan.nextLine();
			
			String sql = "update mymember set mem_ID = ?, mem_name = ? , mem_tel = ?, mem_addr = ?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, name);
			pst.setString(3, tel);
			pst.setString(4, addr);
			
			int c = pst.executeUpdate();
//			System.out.println(c +" 개의 자료가 수정되었습니다.");
			if(c>0) {
				System.out.println("update 작업 성공 ~~~~");
			}else {
				System.out.println( " 수정작업 실패 !!!!!");
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (rs != null)	try {rs.close();} catch (Exception e) {	e.printStackTrace();}
			if (pst != null)	try {	pst.close();} catch (Exception e) {		e.printStackTrace();}
			if (conn != null)	try {	conn.close();} catch (Exception e) { e.printStackTrace();}
		}

	}

	// 자료를 삭제하는 메서드
	private void delete() {
		// '자료 수정' 이나 '자료 삭제'는 회원 ID를 입력 받아 삭제한다.

		System.out.println("============================");
		System.out.println(" \t 자료 삭제 ");
		System.out.println("============================");

		try {

			conn = DButil.getConnection();
			scan.nextLine(); // 입력 버퍼 비우기 !
			System.out.print("삭제할 회원 ID를 입력해주세요 >");
			String id = scan.nextLine();

			
			// delete mymember where mem_id = 123;
			String sql = "Delete mymember WHERE mem_id = ?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			
			int c = pst.executeUpdate();
			System.out.println(c + "개 삭제 완료!");
			System.out.println(id + " 의 자료가 삭제 되었습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null)	try {rs.close(); } catch (Exception e) {e.printStackTrace();}
			if (pst != null)	try {pst.close();} catch (Exception e) {e.printStackTrace();}
			if (conn != null)	try {	conn.close();	} catch (Exception e) {	e.printStackTrace();}
		}

	}

	private void insert() {
		// 자료를 추가하는 메서드
		// '자료추가' 에서는 회원 ID가 중복되는지 여부를 검사해서 중복되면 다시 입력 받도록 한다.
		System.out.println("==============================");
		System.out.println("  \t자료      추가 ");
		System.out.println("==============================");

		try {

//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "sem", "java");

			conn = DButil.getConnection();
			
			String id;
			scan.nextLine(); // 입력 버퍼 비우기 !
			// 중복되는 값이 있는지 비교하기
			while (true) {

				System.out.print("추가할 ID를 입력하세요>");
				id = scan.nextLine();

				// 조회하여 비교하는 sql문 작성하기
				String sql1 = " SELECT count(*) cnt FROM mymember WHERE mem_id = ? ";

				pst = conn.prepareStatement(sql1);
				pst.setString(1, id);
				rs = pst.executeQuery();
				if (rs.next()) {
					// 값이 없으면
					if (rs.getInt("cnt") == 0) {
						break;
					}
					// 값이 있으면
					System.out.println("데이터에 중복되는 값이 있습니다.");
					System.out.println(" 다시 입력해주세요.");
				}
			} // while문 끝

			// 입력할 데이터 받기
			System.out.print("추가할 이름을 입력하세요>");
			String name = scan.nextLine();

			System.out.print("추가할 연락처를 입력하세요>");
			String tel = scan.nextLine();

			System.out.print("추가할 주소를 입력하세요>");
			String addr = scan.nextLine();

			// 데이터를 추가할 sql문 만들기
			// Insert into mymember (mem_ID, MEM_NAME, MEM_TEL, MEM_ADDR) VALUES
			String sql2 = "Insert into mymember VALUES ( ?, ?, ?, ? )";

			pst = conn.prepareStatement(sql2);
			pst.setString(1, id);
			pst.setString(2, name);
			pst.setString(3, tel);
			pst.setString(4, addr);

			int c = pst.executeUpdate();
			System.out.println(c + "개 추가 성공!");
			System.out.println(name + " 의 자료가 추가 되었습니다.");

		} catch (SQLException e) {		
			e.printStackTrace();	
		} finally {
			if (rs != null)		try {		rs.close();		} catch (Exception e) {		e.printStackTrace();	}
			if (pst != null)	try {		pst.close();	} catch (Exception e) {		e.printStackTrace();	}
			if (conn != null)	try {		conn.close();	} catch (Exception e) {		e.printStackTrace();	}
		} // finally 끝

	}// insert 메서드끝

	
	//리턴값도 있고, 파라미터 값도 있어야됨 
	private int count(String id) {

		int count = 0;

		try {
			conn = DButil.getConnection();
			
			String sql = "SELECT count(*) cnt FROM MYMEMBER WHERE = ? ";
			pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			rs = pst.executeQuery();

			if (rs.next()) {
				count = rs.getInt("cnt");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return count;

	}
}
