package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class JdbcBoard {


	Connection conn = null;
	ResultSet res = null;
	PreparedStatement ps = null;
	Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		//게시판 테이블 구조 및 시퀀스 
		
		new JdbcBoard().view();

	}
	
	public void view() {
		
		System.out.println("-----------------------------");
		System.out.println(" NO      제목           작성자     조회수");
		System.out.println("-----------------------------");
		
		try {
			
			conn = DButil3.getConnection();
			
			String sql = "SELECT * FROM jdbc_board ORDER BY  board_no DESC";
			
			ps = 
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
		
		System.out.println();
		System.out.println("-----------------------------");
		
		
		
	}

}
