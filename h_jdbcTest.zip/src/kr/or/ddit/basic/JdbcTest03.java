package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcTest03 {
	
	// 문제2 ) lprod_id값 2개를 차례로 입력받아서 두 값중 작은 값부터 큰 값 사이의 자료들을 출력하시오
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		
		System.out.println("첫번째 lprod_id 값을입력하세요 >");
		int input1 = scan.nextInt();
		System.out.println("두번째 lprod_id 값을입력하세요 >");
		int input2 = scan.nextInt();
		// 방법 4
//		int input1 = Integer.parseInt(scan.next());
//		int input2 = Integer.parseInt(scan.next());
		
		//방법 1
//		int min, max;
//		max = Math.max(input1, input2);
//		min = Math.min(input1, input2);
		
		//방법 2
//		if(input1>input2) {
//			int temp= input1;
//			input1=input2;
//			input2=temp;
//		}
		
		//방법 3
//		if(input>input2) {
//			max = input1;
//			min = input2;
//		}else if(input1<input2) {
//			max = input2;
//			min = input1;
//		}
		
		
		
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");		
			
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost", "sem", "java");
			String sql = "";

			//방법 1~3사용시의 SQL문 
			//String sql = "SELECT * FRIM LPROD WHERE LPROD_ID >= " + MIN + " AND LPROD_ID <= " + MAX;
			
			//방법 4
			if(input1 <input2) {
				sql = "select  * from lprod where lprod_id  BETWEEN " + input1  + " AND " + input2;
			}else{
				sql = "select  * from lprod where lprod_id  BETWEEN " + input2  + " AND " + input1;
			}
			
			System.out.println("실행할 sql문 : " + sql);
			System.out.println();
			
			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);
			
			System.out.println("---------------값의 결과 출력하기-----------------");
			System.out.println("=============================================");			
		
			while(rs.next()) {
				 System.out.println("Lprod_id : " + rs.getInt("lprod_id"));	//잘못입력하면 false로 입력되어 출력되지 않는다
				 System.out.println("Lprod_gu : " + rs.getString("lprod_gu"));
				 System.out.println("Lprod_nm : " +  rs.getString("lprod_nm"));

				System.out.println("=============================================");			
			}
			System.out.println("=============================================");			
			
			
			
		} catch (SQLException e) {
			System.out.println("잘못입력했습니다.");
			e.printStackTrace();	
		} catch (ClassNotFoundException e) {
			System.out.println("잘못입력했습니다.");
			e.printStackTrace();
		}	finally {		//6. 사용했던 자원 반납하기
			if(rs!=null) { try{ rs.close(); } catch(SQLException e) { } }
			if(stmt!=null) { try{ stmt.close(); } catch(SQLException e) { } } 
			if(conn!=null) { try{ conn.close(); } catch(SQLException e) { } }
			
		}

	}

}
